import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { CGridComponent, CGridCellComponent, CGridSpinnerComponent, CCellDataService } from '../cgrid/cgrid.component';

@NgModule({
  declarations: [
    AppComponent,
    CGridComponent,
    CGridCellComponent,
    CGridSpinnerComponent
  ],
  entryComponents: [CGridSpinnerComponent],
  imports: [
    BrowserModule
  ],
  providers: [CCellDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
