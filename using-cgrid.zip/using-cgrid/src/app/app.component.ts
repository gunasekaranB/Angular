import { Component, ViewContainerRef, ViewChild, OnInit } from '@angular/core';
import { CGridComponent, CCellDataService, Column, GridOption } from '../cgrid/cgrid.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'CGrid';
  gridOption: GridOption = new GridOption();
  @ViewChild('gridLoader', { read: ViewContainerRef }) container: ViewContainerRef;
  col1: Column;
  mainData: {}[] = [];
  constructor(public celldataService: CCellDataService) {
    this.col1 = new Column();
    this.col1.field = 'title';
    this.col1.fieldName = 'Title';
    this.col1.isCustom = false;
    this.col1.width = '240px';
    this.col1.allowSorting = true;
    this.col1.allowFiltering = true;
    this.gridOption.columns.push(this.col1);

    this.col1 = new Column();
    this.col1.field = 'isDone';
    this.col1.fieldName = 'IsDone';
    this.col1.isCustom = false;
    this.col1.width = '240px';
    this.col1.allowSorting = false;
    this.col1.allowFiltering = true;
    this.gridOption.columns.push(this.col1);

    this.col1 = new Column();
    this.col1.field = 'Action';
    this.col1.fieldName = 'Action';
    this.col1.isCustom = true;
    this.col1.width = '120px';
    // tslint:disable-next-line:max-line-length
    this.col1.customTemplate = '<table><tr><td><button type="button" class="btn btn-primary" (click)="onclick({\'data\' : row, \'control\': \'Edit\' })" [disabled]="row?.isDone">Edit</button>';
    this.col1.customTemplate = this.col1.customTemplate + '</td><td style="padding: 2px;">';
    // tslint:disable-next-line:max-line-length
    this.col1.customTemplate = this.col1.customTemplate + '<button class="btn btn-danger" (click)="onclick({\'data\' : row, \'control\': \'Delete\' })">Delete</button></td></tr></table>';
    this.gridOption.columns.push(this.col1);

    this.mainData.push({'title': 'task1', 'isDone': false, 'isEditing': false});
    this.mainData.push({'title': 'task2', 'isDone': false, 'isEditing': false});
    this.mainData.push({'title': 'abc', 'isDone': false, 'isEditing': false});
    this.mainData.push({'title': 'uvw', 'isDone': false, 'isEditing': false});

    this.gridOption.data = this.mainData;

    this.gridOption.editTemplate =
    // tslint:disable-next-line:max-line-length
    `<input #isdone type=text [value]="row['title']"><br/><button class="btn btn-danger" (click)="onclick({\'data\' : row, \'control\': \'Update\',\'input\': isdone.value })" >Update</button>
    <button class="btn" (click)="onclick({\'data\' : row, \'control\': \'Cancel\',\'input\': isdone.value })" >Cancel</button>`;
  }

  ngOnInit() {
    this.celldataService.sortClickEmitter.subscribe((data) => {
      this.handleSorting(data);
    });

    this.celldataService.filterClickEmitter.subscribe((data) => {
      this.handleFiltering(data);
    });

    this.celldataService.fireClickEmitter.subscribe((data) => {
      this.handleButtonEvent(data);
    });
  }

  handleSorting(data: {}) {
    if (data || this.gridOption.currentSortField) {
      if (data) {
        this.gridOption.currentSortField = data['field'];
        this.gridOption.currentSortDirection = data['direction'];
      }
      // sort your data according to the fiels and direction and reassign the data to this.gridOption.data
      this.gridOption.data = this.gridOption.data.sort((a: any, b: any) =>
      // tslint:disable-next-line:one-line
      {
        if (a[this.gridOption.currentSortField] > b[this.gridOption.currentSortField]) {
          return this.gridOption.currentSortDirection;
        }else if (a[this.gridOption.currentSortField] < b[this.gridOption.currentSortField]) {
          return -this.gridOption.currentSortDirection;
        }else {
          return 0;
        }
      } );
    }
  }

  handleFiltering(data: {}[]) {
    if (data) {
      this.gridOption.data = this.mainData.filter((value: any, index: any, self: any) => {
        // tslint:disable-next-line:one-line
        const len: number = data.length;
        for (const val of data) {
          if (value[val['field']].toString().indexOf(val['filterValue']) < 0) {
            return false;
          }
        }
        return true;
      });
      this.gridOption.filteredData = data;
      this.handleSorting(undefined);
    }
  }

  handleButtonEvent(data: {}) {
    if (data['control'] === 'Delete') {
        const tsk = data['data'];
        this.celldataService.blockUI(this.container); // block UI
        const newData: {}[] = [];
        this.mainData.forEach((value: any, index: any, self: any) => {
          console.log(value['title']);
          console.log(tsk['title']);
          if (value['title'] !== tsk['title']) {
            newData.push(value);
          }
        });
        this.gridOption.data = newData; // update task
        this.mainData = newData;
        this.handleFiltering(this.gridOption.filteredData);
        this.celldataService.unblockUI();
    }else if (data['control'] === 'Edit') {
      const tsk = data['data'];
      for (const task of this.gridOption.data ){
          if (tsk['title'] === task['title']) {
              task['isEditing'] = true;
          }
      }
    }else if (data['control'] === 'Cancel') {
      const tsk = data['data'];
      for (const task of this.gridOption.data ){
          if (tsk['title'] === task['title']) {
              task['isEditing'] = false;
          }
      }
    }else if (data['control'] === 'Update') {
      const tsk = data['data'];
      const newValue = data['input'];
      for (const task of this.gridOption.data ){
          if (tsk['title'] === task['title']) {
            if (newValue) {
              task['title'] = newValue;
              task['isEditing'] = false;
              this.handleFiltering(this.gridOption.filteredData);
            }
          }
      }
    }
  }
}
