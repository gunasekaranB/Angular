### This is a demo plunker for an Angular2 table component

This demo plnkr demonstrates many Angular2 concepts.  Thse include a Custom Table, a Tri-state Checkbbox, a Multiselect Dropdown with Form intregration, and a Menu plus NavigationService with a DialogService. Visit [https://long2know.com](https://long2know.com) for more demos and discussion..